package controller

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strconv"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	taskdto "github.com/QuantumNous/new-api/dto"
	"github.com/QuantumNous/new-api/model"
	relayconstant "github.com/QuantumNous/new-api/relay/constant"
	"github.com/QuantumNous/new-api/service"
	"github.com/QuantumNous/new-api/setting/system_setting"
	"github.com/gin-gonic/gin"
	"github.com/glebarez/sqlite"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"gorm.io/gorm"
)

type qsControllerTransport func(*http.Request) (*http.Response, error)

func (transport qsControllerTransport) RoundTrip(req *http.Request) (*http.Response, error) {
	return transport(req)
}

func TestQSWANFetchAndDownloadUsePublicTaskID(t *testing.T) {
	db, err := gorm.Open(sqlite.Open(":memory:"), &gorm.Config{})
	require.NoError(t, err)
	rawDB, err := db.DB()
	require.NoError(t, err)
	rawDB.SetMaxOpenConns(1)
	oldDB, oldCache := model.DB, common.MemoryCacheEnabled
	model.DB, common.MemoryCacheEnabled = db, false
	t.Cleanup(func() {
		model.DB, common.MemoryCacheEnabled = oldDB, oldCache
		assert.NoError(t, rawDB.Close())
	})
	require.NoError(t, db.AutoMigrate(&model.Channel{}, &model.Task{}))
	base := "https://qsqs.org"
	ch := &model.Channel{Id: 25, Name: "isolated-qs", Type: constant.ChannelTypeOpenAI, BaseURL: &base, Key: "mock-key"}
	require.NoError(t, db.Create(ch).Error)
	task := &model.Task{
		TaskID: "task_local", UserId: 42, ChannelId: ch.Id,
		Platform: constant.TaskPlatform(strconv.Itoa(ch.Type)), Status: model.TaskStatusSuccess,
		Properties:  model.Properties{OriginModelName: "wan-3.0-per-second", UpstreamModelName: "wan-3.0-per-second"},
		PrivateData: model.TaskPrivateData{UpstreamTaskID: "upstream-id"},
		Data:        []byte(`{"id":"upstream-id","task_id":"upstream-id","status":"completed","video_url":"https://qsqs.org/v1/videos/upstream-id/content"}`),
	}
	require.NoError(t, db.Create(task).Error)

	// Keep the test entirely local; the transport below cannot make network requests.
	fetch := system_setting.GetFetchSetting()
	originalProtection := fetch.EnableSSRFProtection
	fetch.EnableSSRFProtection = false
	if service.GetHttpClient() == nil {
		service.InitHttpClient()
	}
	client := service.GetHttpClient()
	originalTransport := client.Transport
	t.Cleanup(func() {
		client.Transport = originalTransport
		fetch.EnableSSRFProtection = originalProtection
	})
	calls := 0
	client.Transport = qsControllerTransport(func(req *http.Request) (*http.Response, error) {
		calls++
		assert.Equal(t, http.MethodGet, req.Method)
		assert.Equal(t, "https://qsqs.org/v1/videos/upstream-id/content", req.URL.String())
		assert.Equal(t, "Bearer mock-key", req.Header.Get("Authorization"))
		return &http.Response{
			StatusCode: http.StatusOK,
			Header:     http.Header{"Content-Type": {"video/mp4"}},
			Body:       io.NopCloser(strings.NewReader("\x00\x00\x00\x18ftypisom")),
		}, nil
	})

	router := gin.New()
	router.Use(func(c *gin.Context) { c.Set("id", 42); c.Set("relay_mode", relayconstant.RelayModeVideoFetchByID) })
	router.GET("/v1/videos/:task_id", RelayTaskFetch)
	router.GET("/v1/videos/:task_id/content", VideoProxy)

	fetched := httptest.NewRecorder()
	router.ServeHTTP(fetched, httptest.NewRequest(http.MethodGet, "/v1/videos/task_local", nil))
	require.Equal(t, http.StatusOK, fetched.Code, fetched.Body.String())
	assert.Contains(t, fetched.Body.String(), "/v1/videos/task_local/content")
	assert.NotContains(t, fetched.Body.String(), "upstream-id")
	assert.Zero(t, calls)

	video := httptest.NewRecorder()
	router.ServeHTTP(video, httptest.NewRequest(http.MethodGet, "/v1/videos/task_local/content", nil))
	require.Equal(t, http.StatusOK, video.Code, video.Body.String())
	assert.Equal(t, "video/mp4", video.Header().Get("Content-Type"))
	assert.Equal(t, "\x00\x00\x00\x18ftypisom", video.Body.String())
	assert.Equal(t, 1, calls)
}

func TestQSWANTerminalSubmissionFailureDoesNotRetry(t *testing.T) {
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	err := &taskdto.TaskError{Code: "upstream_video_failed", StatusCode: http.StatusBadGateway}
	assert.False(t, shouldRetryTaskRelay(c, 25, err, 2))
}
