# CZL 首页与 QS 视频整合候选

本候选以本地 New API 源码 `f1164142` 为底，保留原工作区已有的 521 视频渠道和令牌页面改动。首页使用 GitHub `chenchao1122/czl-api` 提交 `cb9c0ea` 中 11 月 15 日两份备份的差异合并，只导入首页文件与对应中文文案。

QS 修复限定于 `https://qsqs.org` 的 `wan-3.0-per-second`。经渠道模型映射后，网关校验并统一 `seconds` 和 `duration`，缺省为 15 秒，可用范围为 10–30 秒。请求发给上游的时长也是用于本地预扣的时长；余额不足或时长非法时不提交任务，上游立即报告任务失败时退回预扣。任务查询和下载继续使用网关任务 ID。

本地候选使用此版本已有的固定模型单价入口，由 QS 适配器把配置的单价乘以秒数。测试使用模拟上游和隔离数据库，无真实任务费用。两款 W3 Prime 未纳入此次接入。

线上镜像 `czl/new-api:homepage-mobilefix-20261115` 的完整后端没有包含在首页备份里。生产已有独立的 `per_second` 计费入口；直接替换为此早期底座可能丢失后续改动。上线前需在匹配生产的源码里合入 QS 适配并接入原有按秒判断，确认只能乘一次秒数，再做隔离回归与真实短视频验证。

本地复验命令：

```sh
go test -count=1 ./relay ./relay/channel/task/sora ./relay/common ./setting/ratio_setting ./controller
cd web
bun install --frozen-lockfile
bun run build:check
bun run test src/features/home src/features/keys src/components/data-table/core src/lib/__tests__/api.test.ts
```

整合在本地独立分支完成，未修改原工作区、GitHub 仓库或生产服务器。
