package sora

import (
	"bytes"
	"fmt"
	"mime"
	"net/http"
	"strconv"
	"strings"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/constant"
	"github.com/QuantumNous/new-api/dto"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	"github.com/QuantumNous/new-api/service"
	"github.com/gin-gonic/gin"
)

const qsWanModel = "wan-3.0-per-second"

func isQSVideoBase(baseURL string) bool {
	return strings.TrimRight(baseURL, "/") == "https://qsqs.org"
}

type qsVideoRequest struct {
	body    []byte
	seconds int
}

// PrepareMappedTask validates the exact outbound duration before preconsumption.
// Use the same canonical duration in EstimateBilling and BuildRequestBody.
func (a *TaskAdaptor) PrepareMappedTask(c *gin.Context, info *relaycommon.RelayInfo) *dto.TaskError {
	if !isQSVideoBase(a.baseURL) || info.UpstreamModelName != qsWanModel {
		return nil
	}
	contentType, _, _ := mime.ParseMediaType(c.GetHeader("Content-Type"))
	if contentType != "application/json" || info.Action == constant.TaskActionRemix {
		return service.TaskErrorWrapperLocal(fmt.Errorf("QS WAN requires a JSON video generation request"), "invalid_request", http.StatusBadRequest)
	}

	var body map[string]qsJSONValue
	if err := common.UnmarshalBodyReusable(c, &body); err != nil || body == nil {
		return service.TaskErrorWrapperLocal(fmt.Errorf("QS WAN requires a JSON object"), "invalid_request", http.StatusBadRequest)
	}

	seconds, err := qsWanDuration(body["seconds"], body["duration"])
	if err != nil {
		return service.TaskErrorWrapperLocal(err, "invalid_seconds", http.StatusBadRequest)
	}
	body["model"], _ = common.Marshal(qsWanModel)
	body["seconds"], _ = common.Marshal(strconv.Itoa(seconds))
	delete(body, "duration")
	encoded, err := common.Marshal(body)
	if err != nil {
		return service.TaskErrorWrapperLocal(err, "invalid_request", http.StatusBadRequest)
	}
	a.qsRequest = &qsVideoRequest{body: encoded, seconds: seconds}
	return nil
}

// Keep the original JSON representation of fields outside the adapter contract.
type qsJSONValue []byte

func (v *qsJSONValue) UnmarshalJSON(data []byte) error {
	*v = append((*v)[:0], data...)
	return nil
}

func (v qsJSONValue) MarshalJSON() ([]byte, error) {
	return []byte(v), nil
}

func qsWanDuration(seconds, duration qsJSONValue) (int, error) {
	effective := 0
	for _, value := range []qsJSONValue{seconds, duration} {
		value := bytes.TrimSpace(value)
		if len(value) == 0 || bytes.Equal(value, []byte("null")) {
			continue
		}
		p := string(value)
		if value[0] == '"' {
			if err := common.Unmarshal(value, &p); err != nil {
				return 0, err
			}
			if p == "" {
				continue
			}
		}
		n, err := strconv.ParseUint(p, 10, 8)
		if err != nil || n < 10 || n > 30 {
			return 0, fmt.Errorf("QS WAN requires an integer duration between 10 and 30 seconds")
		}
		if effective != 0 && effective != int(n) {
			return 0, fmt.Errorf("seconds and duration must agree")
		}
		effective = int(n)
	}
	if effective == 0 {
		effective = 15
	}
	return effective, nil
}
