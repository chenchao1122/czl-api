package sora

var ModelList = []string{
	"sora-2",
	"sora-2-pro",
	"521ai-SD-HD",
	"521ai-SD-4K",
	"521ai-SD",
	"521ai-SD-480",
	"521ai-SD-Mini-720",
	"521ai-SD-Mini-480",
}

var ChannelName = "sora"

var model521VideoSet = map[string]struct{}{
	"521ai-SD-HD":       {},
	"521ai-SD-4K":       {},
	"521ai-SD":          {},
	"521ai-SD-480":      {},
	"521ai-SD-Mini-720": {},
	"521ai-SD-Mini-480": {},
}

func is521VideoModel(model string) bool {
	_, ok := model521VideoSet[model]
	return ok
}
