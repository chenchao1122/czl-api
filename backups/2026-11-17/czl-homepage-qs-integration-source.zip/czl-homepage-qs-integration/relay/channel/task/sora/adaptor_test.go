package sora

import (
	"bytes"
	"io"
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestSoraBuildRequestBodyReturnsReplayablePassThroughBody(t *testing.T) {
	payload := []byte("opaque-sora-request-body")
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/videos", bytes.NewReader(payload))
	c.Request.Header.Set("Content-Type", "application/octet-stream")
	defer common.CleanupBodyStorage(c)

	info := &relaycommon.RelayInfo{}
	body, err := (&TaskAdaptor{}).BuildRequestBody(c, info)
	require.NoError(t, err)
	replayable, ok := body.(common.ReplayableBody)
	require.True(t, ok)

	sent, err := io.ReadAll(body)
	require.NoError(t, err)
	assert.Equal(t, payload, sent)
	assert.EqualValues(t, len(payload), replayable.Size())

	replayBody, err := replayable.NewReader()
	require.NoError(t, err)
	replay, err := io.ReadAll(replayBody)
	require.NoError(t, err)
	require.NoError(t, replayBody.Close())
	assert.Equal(t, payload, replay)
}

func Test521VideoDurationValidation(t *testing.T) {
	tests := []struct {
		name       string
		seconds    string
		wantStatus int
	}{
		{name: "minimum", seconds: "4"},
		{name: "maximum", seconds: "15"},
		{name: "below minimum", seconds: "3", wantStatus: http.StatusBadRequest},
		{name: "above maximum", seconds: "16", wantStatus: http.StatusBadRequest},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			payload := []byte(`{"model":"521ai-SD-Mini-480","prompt":"a cat","seconds":"` + tt.seconds + `"}`)
			c, _ := gin.CreateTestContext(httptest.NewRecorder())
			c.Request = httptest.NewRequest(http.MethodPost, "/v1/videos", bytes.NewReader(payload))
			c.Request.Header.Set("Content-Type", "application/json")
			defer common.CleanupBodyStorage(c)

			taskErr := (&TaskAdaptor{}).ValidateRequestAndSetAction(c, &relaycommon.RelayInfo{
				TaskRelayInfo: &relaycommon.TaskRelayInfo{},
			})
			if tt.wantStatus == 0 {
				require.Nil(t, taskErr)
				return
			}
			require.NotNil(t, taskErr)
			assert.Equal(t, tt.wantStatus, taskErr.StatusCode)
			assert.Equal(t, "invalid_seconds", taskErr.Code)
		})
	}
}

func TestParseCompleted521VideoResultURL(t *testing.T) {
	payload := []byte(`{
		"id":"upstream_video_1",
		"status":"completed",
		"metadata":{"video_url":"https://cdn.example.com/video.mp4"}
	}`)

	result, err := (&TaskAdaptor{}).ParseTaskResult(payload)
	require.NoError(t, err)
	require.NotNil(t, result)
	assert.Equal(t, model.TaskStatusSuccess, result.Status)
	assert.Equal(t, "https://cdn.example.com/video.mp4", result.Url)
}

func Test521VideoBillingUsesSecondsWithoutExtraSizeMultiplier(t *testing.T) {
	payload := []byte(`{"model":"521ai-SD-4K","prompt":"a cat","seconds":"6","size":"1792x1024"}`)
	c, _ := gin.CreateTestContext(httptest.NewRecorder())
	c.Request = httptest.NewRequest(http.MethodPost, "/v1/videos", bytes.NewReader(payload))
	c.Request.Header.Set("Content-Type", "application/json")
	defer common.CleanupBodyStorage(c)

	info := &relaycommon.RelayInfo{TaskRelayInfo: &relaycommon.TaskRelayInfo{}}
	require.Nil(t, (&TaskAdaptor{}).ValidateRequestAndSetAction(c, info))
	ratios := (&TaskAdaptor{}).EstimateBilling(c, info)

	assert.Equal(t, float64(6), ratios["seconds"])
	assert.Equal(t, float64(1), ratios["size"])
}
