package sora

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"

	"github.com/QuantumNous/new-api/common"
	"github.com/QuantumNous/new-api/model"
	relaycommon "github.com/QuantumNous/new-api/relay/common"
	"github.com/gin-gonic/gin"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestQSWANUsesOneDurationForBillingAndSubmission(t *testing.T) {
	for _, tc := range []struct {
		name, fields, seconds string
	}{
		{"default", "", "15"},
		{"min", `,"seconds":10`, "10"},
		{"max via duration alias", `,"duration":"30"`, "30"},
		{"agreeing aliases", `,"seconds":"12","duration":12`, "12"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			c, _ := gin.CreateTestContext(httptest.NewRecorder())
			c.Request = httptest.NewRequest(http.MethodPost, "/v1/videos", strings.NewReader(`{"model":"local-alias","prompt":"test","size":"1792x1024","resolution":"720p","generate_audio":false`+tc.fields+`}`))
			c.Request.Header.Set("Content-Type", "application/json")
			defer common.CleanupBodyStorage(c)
			info := &relaycommon.RelayInfo{TaskRelayInfo: &relaycommon.TaskRelayInfo{}, ChannelMeta: &relaycommon.ChannelMeta{UpstreamModelName: qsWanModel}}
			a := &TaskAdaptor{baseURL: "https://qsqs.org"}
			require.Nil(t, a.ValidateRequestAndSetAction(c, info))
			info.UpstreamModelName = qsWanModel
			require.Nil(t, a.PrepareMappedTask(c, info))
			r, err := a.BuildRequestBody(c, info)
			require.NoError(t, err)
			b, err := io.ReadAll(r)
			require.NoError(t, err)
			var result map[string]any
			require.NoError(t, common.Unmarshal(b, &result))
			assert.Equal(t, tc.seconds, result["seconds"])
			assert.Equal(t, qsWanModel, result["model"])
			assert.Equal(t, "720p", result["resolution"])
			assert.Equal(t, false, result["generate_audio"])
			assert.NotContains(t, result, "duration")
			var expected float64
			require.NoError(t, common.UnmarshalJsonStr(tc.seconds, &expected))
			assert.Equal(t, map[string]float64{"seconds": expected}, a.EstimateBilling(c, info))
		})
	}
}

func TestQSWANRejectsInvalidDurationBeforeBilling(t *testing.T) {
	for _, fields := range []string{`"seconds":"9"`, `"duration":31`, `"seconds":10,"duration":11`, `"seconds":"abc"`, `"seconds":10.01`, `"seconds":false`, `"seconds":99999999999`} {
		t.Run(fields, func(t *testing.T) {
			c, _ := gin.CreateTestContext(httptest.NewRecorder())
			c.Request = httptest.NewRequest(http.MethodPost, "/v1/videos", strings.NewReader("{"+fields+"}"))
			c.Request.Header.Set("Content-Type", "application/json")
			defer common.CleanupBodyStorage(c)
			a := &TaskAdaptor{baseURL: "https://qsqs.org"}
			info := &relaycommon.RelayInfo{TaskRelayInfo: &relaycommon.TaskRelayInfo{}, ChannelMeta: &relaycommon.ChannelMeta{UpstreamModelName: qsWanModel}}
			err := a.PrepareMappedTask(c, info)
			require.NotNil(t, err)
			assert.Equal(t, http.StatusBadRequest, err.StatusCode)
			assert.Equal(t, "invalid_seconds", err.Code)
		})
	}
}

func TestQSWANVideoResultUsesLocalDownloadAndKeepsFailureReason(t *testing.T) {
	a := &TaskAdaptor{baseURL: "https://qsqs.org"}
	failed, err := a.ParseTaskResult([]byte(`{"status":"failed","error":"upstream render failed"}`))
	require.NoError(t, err)
	assert.Equal(t, string(model.TaskStatusFailure), failed.Status)
	assert.Equal(t, "upstream render failed", failed.Reason)

	completed := []byte(`{"id":"upstream-private","task_id":"upstream-private","status":"completed","video_url":"https://qsqs.org/v1/videos/upstream-private/content"}`)
	status, err := a.ParseTaskResult(completed)
	require.NoError(t, err)
	assert.Equal(t, string(model.TaskStatusSuccess), status.Status)
	assert.Empty(t, status.Url)

	task := &model.Task{TaskID: "task_local", Status: model.TaskStatusSuccess, Data: completed}
	task.Properties.UpstreamModelName = qsWanModel
	body, err := a.ConvertToOpenAIVideo(task)
	require.NoError(t, err)
	assert.NotContains(t, string(body), "upstream-private")
	assert.Contains(t, string(body), "/v1/videos/task_local/content")
}
