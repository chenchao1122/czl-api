/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

For commercial licensing, please contact support@quantumnous.com
*/
import { Link } from '@tanstack/react-router'
import { ArrowRight } from 'lucide-react'
import { useMemo } from 'react'
import { useTranslation } from 'react-i18next'

import { AnimateInView } from '@/components/animate-in-view'
import { Button } from '@/components/ui/button'
import { usePricingData } from '@/features/pricing/hooks/use-pricing-data'
import { formatPrice, formatRequestPrice } from '@/features/pricing/lib/price'
import { ModelBillingModeBadge } from '@/features/pricing/components/model-billing-mode-badge'
import type { PricingModel } from '@/features/pricing/types'

import { selectFeaturedModels } from '../../lib/featured-models'

function getModelPrice(
  model: PricingModel,
  priceRate: number,
  usdExchangeRate: number,
  t: ReturnType<typeof useTranslation>['t']
): string {
  if (model.billing_mode === 'tiered_expr') return t('Dynamic Pricing')

  if (model.quota_type === 1) {
    const unit = model.billing_mode === 'per_second' ? 'second' : 'request'
    return `${formatRequestPrice(model, false, priceRate, usdExchangeRate)} / ${t(unit)}`
  }

  return `${formatPrice(model, 'input', 'M', false, priceRate, usdExchangeRate)} / 1M ${t('tokens')}`
}

export function FeaturedModels() {
  const { t } = useTranslation()
  const { models, isLoading, priceRate, usdExchangeRate } = usePricingData()
  const featuredModels = useMemo(() => selectFeaturedModels(models), [models])

  if (isLoading || featuredModels.length === 0) return null

  return (
    <section className='border-border/40 relative z-10 border-y px-6 py-14 md:py-16'>
      <div className='mx-auto max-w-6xl'>
        <div className='mb-6 flex flex-wrap items-end justify-between gap-4'>
          <div className='max-w-2xl'>
            <p className='text-muted-foreground mb-2 text-xs font-medium tracking-widest uppercase'>
              {t('Model Square')}
            </p>
            <h2 className='text-xl font-bold tracking-tight md:text-2xl'>
              {t('Available Models')}
            </h2>
          </div>
          <Button
            variant='outline'
            className='group h-9 rounded-lg px-3 text-sm'
            render={<Link to='/pricing' />}
          >
            {t('Model Square')}
            <ArrowRight className='ml-1.5 size-4 transition-transform group-hover:translate-x-0.5' />
          </Button>
        </div>

        <div className='grid gap-3 md:grid-cols-3'>
          {featuredModels.map((model, index) => (
            <AnimateInView key={model.model_name} delay={index * 80}>
              <Link
                to='/pricing'
                className='border-border/60 bg-background hover:bg-muted/20 block h-full rounded-lg border p-4 transition-colors'
              >
                <div className='flex min-w-0 items-start justify-between gap-3'>
                  <h3 className='text-foreground min-w-0 break-all font-mono text-sm font-semibold'>
                    {model.model_name}
                  </h3>
                  {model.vendor_name ? (
                    <span className='text-muted-foreground shrink-0 text-xs'>
                      {model.vendor_name}
                    </span>
                  ) : null}
                </div>
                <div className='text-muted-foreground mt-3 flex flex-wrap items-center gap-2 text-sm'>
                  <span className='text-foreground font-mono font-semibold'>
                    {getModelPrice(model, priceRate, usdExchangeRate, t)}
                  </span>
                  <ModelBillingModeBadge model={model} />
                </div>
              </Link>
            </AnimateInView>
          ))}
        </div>
      </div>
    </section>
  )
}
