/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

For commercial licensing, please contact support@quantumnous.com
*/
import type { PricingModel } from '@/features/pricing/types'

const FEATURED_MODEL_NAMES = ['sd-fast-720', 'seedream-5-pro', 'gpt-image-2']

function normalizeModelName(name: string): string {
  return name.toLowerCase().replaceAll(/[\s_]+/g, '-')
}

export function selectFeaturedModels(models: PricingModel[]): PricingModel[] {
  const selected = FEATURED_MODEL_NAMES.flatMap((needle) => {
    const match = models.find((model) =>
      normalizeModelName(model.model_name).includes(needle)
    )
    return match ? [match] : []
  })

  for (const model of models) {
    if (selected.length >= 3) break
    if (!selected.some((item) => item.model_name === model.model_name)) {
      selected.push(model)
    }
  }

  return selected.slice(0, 3)
}
