/*
Copyright (C) 2023-2026 QuantumNous

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU Affero General Public License as
published by the Free Software Foundation, either version 3 of the
License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU Affero General Public License for more details.

You should have received a copy of the GNU Affero General Public License
along with this program. If not, see <https://www.gnu.org/licenses/>.

For commercial licensing, please contact support@quantumnous.com
*/
import { describe, expect, it } from 'vitest'

import type { PricingModel } from '@/features/pricing/types'

import { selectFeaturedModels } from '../lib/featured-models'

function model(modelName: string): PricingModel {
  return {
    id: modelName.length,
    model_name: modelName,
    quota_type: 1,
    model_ratio: 1,
    completion_ratio: 1,
    enable_groups: [],
  }
}

describe('selectFeaturedModels', () => {
  it('prioritizes the configured video, image, and text showcase models', () => {
    const result = selectFeaturedModels([
      model('gpt-4o-mini'),
      model('gpt-image-2'),
      model('SD-fast-720'),
      model('Seedream 5 Pro'),
    ])

    expect(result.map((item) => item.model_name)).toEqual([
      'SD-fast-720',
      'Seedream 5 Pro',
      'gpt-image-2',
    ])
  })

  it('fills missing showcase models with unique live catalog entries', () => {
    const result = selectFeaturedModels([
      model('SD-fast-720'),
      model('chat-model'),
      model('image-model'),
      model('extra-model'),
    ])

    expect(result.map((item) => item.model_name)).toEqual([
      'SD-fast-720',
      'chat-model',
      'image-model',
    ])
  })
})
